define([], function() {
  return {
    "PropertyPaneDescription": "Happy Brithday",
    "BasicGroupName": "Properties",
    "DescriptionFieldLabel": "Title",
    "NumberUpComingDaysLabel": 'Number of upcomming birthdays',
    "BirthdayControlDefaultDay": "Today",
    "HappyBirthdayMsg": "Happy Birthday!",
    "NextBirthdayMsg": "Next Birthday",
    "HappyAnniversaryMsg": "Happy Anniversary!",
    "NextAnniversaryMsg": "Next Anniversary",
    "MessageNoBirthdays": "There are no birthdays and anniversaries for the next days."
  }
});